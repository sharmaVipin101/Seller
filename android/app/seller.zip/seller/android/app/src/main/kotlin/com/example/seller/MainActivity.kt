package com.example.seller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
