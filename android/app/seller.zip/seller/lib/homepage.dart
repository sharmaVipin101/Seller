import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class HomePage extends StatefulWidget {

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final firestoreInstance = Firestore.instance;

  void addit() async{

    var firebaseUser = await FirebaseAuth.instance.currentUser();
    firestoreInstance.collection('posts').document(firebaseUser.uid)
    .setData({
      "photoUrl": "myphotoUrl",
      "name": firebaseUser.displayName,
      "caption": "my _captionInputController.text",
      "date": DateTime.now(),
      "uploadedBy": firebaseUser.uid
    });
  }
  void deleteit()async{

    var firebaseUser = await FirebaseAuth.instance.currentUser();
    firestoreInstance.collection('posts').document(firebaseUser.uid).delete().then((_){
      print('deleted');
    });



  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(
              child:RaisedButton(
                onPressed: (){
                  addit();
                },
                child: Text(
                  'add data'
                ),
              )
          ),
          Center(
              child:RaisedButton(
                onPressed: (){
                  deleteit();
                },
                child: Text(
                  'delete data'
                ),
              )
          ),
        ],
      ),
    );
  }
}
